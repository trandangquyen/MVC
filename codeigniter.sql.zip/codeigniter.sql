-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2017 at 05:30 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8,
  `parent` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `parent`) VALUES
(1, 'Tivi', 'Các sản phẩm tivi', NULL),
(2, 'Điện thoại', 'Các sản phẩm điện thoại', NULL),
(3, 'Laptop', 'Máy tính xách tay', NULL),
(4, 'Toshiba', NULL, 1),
(5, 'Samsung', NULL, 1),
(6, 'Panasonic', NULL, 1),
(7, 'LG', NULL, 1),
(8, 'HTC', NULL, 2),
(9, 'BlackBerry', NULL, 2),
(10, 'Asus', NULL, 2),
(11, 'Apple', NULL, 2),
(12, 'HP', NULL, 3),
(13, 'Dell', NULL, 3),
(14, 'Asus', NULL, 3),
(15, 'Acer', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `price` bigint(20) NOT NULL DEFAULT '0',
  `category_id` varchar(255) DEFAULT NULL,
  `description` text CHARACTER SET utf8,
  `rate` int(1) DEFAULT NULL,
  `views` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `category_id`, `description`, `rate`, `views`) VALUES
(1, 'LG 32 inch 32LF510D', 5490000, '1,7', NULL, NULL, 0),
(2, 'Samsung 32 inch UA32J4003', 5590000, '1,5', NULL, NULL, 0),
(3, 'iPhone 6s 16GB', 10000000, '2,11', NULL, NULL, 0),
(4, 'Xiaomi Mi MIX (6GB/256GB)', 17000000, '2', NULL, NULL, 0),
(5, 'HTC Desire 628', 4000000, '2,8', NULL, NULL, 0),
(6, 'HTC U Ultra', 3000000, '2,8', 'Màn hình\r\nCông nghệ màn hình	Super LCD\r\nĐộ phân giải	2K (1440 x 2560 pixels)\r\nMàn hình rộng	Chính: 5.7\", phụ: 2.05\"\r\nMặt kính cảm ứng	Corning Gorilla Glass 5', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
