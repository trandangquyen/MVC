-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2017 at 10:55 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(9) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8,
  `parent` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `parent`) VALUES
(1, 'Tivi', 'Các sản phẩm tivi', NULL),
(2, 'Điện thoại', 'Các sản phẩm điện thoại', NULL),
(3, 'Laptop', 'Máy tính xách tay', NULL),
(4, 'Toshiba', NULL, 1),
(5, 'Samsung', NULL, 1),
(6, 'Panasonic', NULL, 1),
(7, 'LG', NULL, 1),
(8, 'HTC', NULL, 2),
(9, 'BlackBerry', NULL, 2),
(10, 'Asus', NULL, 2),
(11, 'Apple', NULL, 2),
(12, 'HP', NULL, 3),
(13, 'Dell', NULL, 3),
(14, 'Asus', NULL, 3),
(15, 'Acer', NULL, 3),
(16, 'MSI', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(9) NOT NULL,
  `product_id` int(9) NOT NULL,
  `email` varchar(250) NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `product_id`, `email`, `name`, `content`, `time`) VALUES
(1, 1, 'dsf@gmail.com', 'bao', 'Sản phẩm chất lượng cao', '2017-05-17 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(9) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `content`) VALUES
(1, 'fdgdf', 'dfgfgdgfd', 'gfdgdfdfg', 'dfggdfdfgdgf'),
(2, 'fdgdf', 'dfgfgdgfd', 'gfdgdfdfg', 'dfggdfdfgdgf'),
(3, 'Vo van khoa', 'khoa@kk.com', '000000', 'hay lam'),
(4, 'Vo van khoa', 'khoa@kk.com', '000000', 'hay lam'),
(5, 'Vo van khoa', 'khoa@kk.com', '000000', 'hay lam'),
(6, 'Vo van khoa', 'khoa@kk.com', '000000', 'hay lam'),
(7, 'Vo van khoa', 'khoa@kk.com', '000000', 'hay lam');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(9) NOT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  `product_id` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `title`, `url`, `product_id`) VALUES
(1, 'anh 1', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 7),
(2, 'anh 2', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-3-500x500.jpg', 7),
(3, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 1),
(4, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 1),
(5, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 2),
(6, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 2),
(7, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 3),
(8, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 3),
(9, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 4),
(10, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 4),
(11, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 5),
(12, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 5),
(13, 'anh', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 6);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(9) NOT NULL,
  `title` varchar(250) NOT NULL,
  `content` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `date`) VALUES
(1, 'Đánh giá nhanh MSI GP72 7REX: Thiết kế cứng cáp, hệ thống tản nhiệt quá ổn!', 'Là một dòng Notebook Gaming thuộc phân khúc tầm trung với mức giá dưới 30.000.000 vnđ của thương hiệu MSI Notebook Gaming nổi tiếng. Ngày hôm nay chúng ta sẽ cùng nghiên cứu thử phiên bản MSI GP72 7REX vừa được về kho Hàng Chính Hiệu vài ngày...\r\n\r\n[​IMG]\r\n\r\nĐánh giá ngoại hình\r\n\r\nNói sơ quá hướng sắp xếp các Series Notebook Gaming của MSI, chúng ta sẽ có 2 dòng Notebook cao cấp nhất về cả thiết kế lẫn cấu hình là GT Series và GS Series. Từ 2 nền tảng này, MSI sẽ có nhữnq tinh chỉnh, cắt giảm vừa đủ để hạ giá thành và cho ra đời các phiên bản dòng GE - GP và GL Series. Thế nên với mẫu ngày hôm nay trên tay, GP72 7REX mặc định sẽ có thiết kế được thừa hưởng, cắt giảm bớt của những đàn anh như GT72 hoặc GS72..\r\n\r\n[​IMG]\r\n\r\nĐó là lý thuyết, ban đầu trước khi được giao để đánh giá mẫu MSI GP72 7REX này, mình cũng sẽ nghĩ MSI sẽ có nhiều hướng cắt giảm đáng kể để giảm giá thành và khiến máy nằm ở phân khúc dưới 30.000.000 vnđ. Tùy thuộc vào đội ngũ thiết kế, sự cắt giảm có thể sẽ rất nặng nhằm khiến dòng máy mất đi cái chất của một mẫu Notebook Gaming. Tuy nhiên thực tế, sau khi trên tay được dòng máy và unbox, mình đã có những cảm nghĩ khác và gần như chắc chắn MSI đã dánh đổi rất nhiều về tài chính để vẫn giữ được một mẫu Notebook Gaming không quá ọp ẹp như những phiên bản trước đây.\r\n\r\n[​IMG]\r\n\r\nMáy dày và nặng là những gì mình cảm nhận được.. Thế nhưng, MSI đã hơi \"ăn gian\" cả về ngôn ngữ thiết kế khi với những đường vát cạnh lại khiến máy khi lên hình trông khá mỏng. Sử dụng lớp vỏ nhựa pha cao cấp, máy không có hiện tượng ọp ẹp khi bóp ở các gờ cạnh cũng như khi nhấc bằng 1 tay, lớp vỏ nhựa của máy cũng không bị bẻ cong hoặc xê dịch quá nhiều - điều mà các bạn thường cảm nhận được mỗi khi cầm những dòng Notebook rẻ tiền. Thế nhưng, máy nặng 2.7gk một cách \"hợp lý\", nó hợp lý cả về kích thước lẫn ngoại hình của mẫu MSI GP72 7REX này..\r\n\r\n[​IMG]\r\n\r\nNghĩ mà xem, một cỗ máy được thiết kế to nếu cố tình làm cho nó nhẹ đi quá nhiều sẽ khiến người dùng cảm thấy máy không được cứng cáp. Và MSI đã ăn điểm ở góc nhìn này của mình, chiều dày, cân nặng và kích thước hợp lý đến mức hoàn hảo. Bạn sẽ không thể phàn nàn vì sao máy nặng kể cả khi vác nó lên vai hoặc xách nó ra đường để dạo chơi một buổi chiều ngoài quán caffe cùng bạn bè..\r\n\r\n[​IMG]\r\n\r\nVới hướng thiết kế quen thuộc trên nắp capo nhôm của những dòng Notebook Gaming, MSI vẫn giữ nguyên tên thương hiệu cùng một tấm khiên có logo rồng cuộn ngay giữa, biểu tượng rồng cuộn vẫn sẽ được sáng lên dựa trên tấm nền Panel màn hình phía sau - tức bạn không thể tắt được logo này, mỗi khi màn hình sáng con rồng cũng sẽ sáng theo. Phía trong, mặt bàn phím không có bất kỳ góc cạnh cắt xéo nào gây hiệu ứng cảm quan ấn tượng. MSI vẫn giữ nguyên nhà sản xuất bàn phím SteelSeries, với thiết kế bàn phím được làm thấp xuống một cách \"khó thấy\" nếu như bạn không tinh ý ở những góc trên, mục đích làm lõm bàn phím vẫn là để tránh va chạm với màn hình mỗi khi bạn đóng xuống và mang vác đi với nhiều vấn đề phát sinh. \r\n\r\n[​IMG]\r\n\r\nCá nhân mình thích thiết kế bàn phím của MSI trên các dòng Notebook Gaming thời gian gần đây, nó không quá nông cũng không quá sâu.. mức gõ phím vừa đủ với một người thích \"chém gió\" trên mạng hoặc làm việc nhiều với các văn bản. Bạn có thể nhanh chóng đạt tốc độ gõ phím khoản 80-90 ký tự/phút nếu làm quen hệ thống bàn phím này trong 2 tiếng. Tuy nhiên cá nhân mình vẫn gặp một số rắc rối khi gõ bên cụm phím Numpad vốn được MSI làm khá dính và đồng bộ với cụm phím chữ, có lẽ cần thời gian dài hơn để làm quen.\r\n\r\n[​IMG]\r\n\r\nTương tự như các dòng Notebook Gaming cao cấp khác, MSI cũng trang bị 3 phím bấm riêng quen thuộc bên ngoài dãy bàn phím thông thường gồm phím Power - Phím thay đổi khu vực sáng đèn LED và nút Cooler Booster đời thứ 4. Riêng nút Cooler Booster sẽ có một đèn LED phụ màu xanh để báo hiệu kích hoạt vào ban đêm.. Cảm quan về Cooler Booster mình sẽ nói thêm bên dưới.\r\n\r\n[​IMG]\r\n\r\nMáy dày một phần vì MSI vẫn còn giữ hệ thống ổ đĩa DVD bên cạnh phải của máy, cá nhân mình một người đã hơn 6 năm nay không đụng vào bất kỳ một đĩa cứng nào thì đó là một phần cứng thừa thãi và tăng chi phí không cần thiết. Tuy nhiên với đối tượng là sinh viên, có thể bạn vẫn còn cần ổ đĩa DVD này vì một số lý do \"củ chuối\" nào đó từ nhà trường yêu cầu. Thế nhưng dày cũng chưa hẳn là xấu, bởi lẽ máy dày đồng nghĩa với việc thể tích bên trong được tăng lên kha khá, đủ để tạo vùng không khí thông thoáng giúp máy có khả năng tản nhiệt tốt hơn.\r\n\r\n[​IMG]\r\n\r\nCạnh đáy của MSI GP72 7REX không có quá nhiều thay đổi so với những phiên bản tiền nhiệm, có lẽ với lối thiết kế chi chít lỗ thông gió, MSI đã khá thành công trong lối thiết kế hệ thống tản nhiệt cho dòng GP Series trước đây. Cộng với việc MSI đã có những nâng cấp về hệ thống tản nhiệt khi tăng số lượng ống đồng lên đáng kể trong cụm tản nhiệt của MSI GP72, có lẽ sẽ không có quá nhiều bất ngờ nếu chiếc Notebook này có hiệu năng tản nhiệt ấn tượng nhỉ?\r\n\r\nNói nhanh qua số lượng cổng kết nối của MSI GP72 7REX, chúng ta sẽ có số lượng cổng kết nối như sau', '2017-05-06 08:43:28'),
(2, 'Đánh giá MSI GE62 7RE phiên bản Camo Squad - Vẻ ngoài ngầu hơn, build nhựa, giá hơn 30 triệu', 'Dòng GE-series là dòng laptop chơi game thuộc phân khúc tầm trung của MSI, cấu hình phần cứng mạnh hơn hai dòng GL-series và GP-series nhưng lại không có trọng lượng mỏng nhẹ hay sức mạnh cơ bắp như trên hai dòng cao cấp hơn là GS-series và GT-series. Và để tạo được làn gió mới cho game thủ, MSI quyết định tung ra phiên bản đặc biệt của dòng GE-series mang tên Camo Squad với tông màu được sử dụng trong quân đội để ngụy trang giúp mang đến sự hút mắt và hầm hố hơn rất nhiều. Trong bài viết này, mình sẽ chia sẻ những trải nghiệm và đánh giá cá nhân về phiên bản Camo Squad này để bạn có được góc nhìn chi tiết hơn, và phiên bản mình đánh giá là phiên bản GE62 7RE với cấu hình phần cứng gần như là mạnh nhất tính đến thời điểm hiện tại. Giá bán chính thức cho phiên bản GE62 7RE Camo Squad tính tại thời điểm bài viết hơn 30 triệu đồng, một lưu ý chính là chỉ có duy nhất chiếc GE62 7RE được trang trí họa tiết Camo Squad và không có bất kì phiên bản nào khác, cũng như mức chênh lệch giá giữa phiên bản thường GE62VR 7RF APACHE PRO và Camo Squad vào khoảng 2,5 triệu đồng cùng cấu hình.\r\n\r\n​\r\n\r\nNgoài ra, MSI còn có phiên bản GE62 7RE Camo Squad được trang bị card đồ họa GTX 1060 nhưng chỉ áp dụng đối với thị trường Mĩ, đối với thị trường Việt Nam chỉ được trang bị cao nhất là GTX 1050 Ti mà thôi.\r\n\r\nThiết kế\r\n\r\nXét về mặt tổng thể thì GE62 7RE Camo Squad không hề có sự khác biệt gì so với phiên bản GE62 thường, toàn bộ phần mặt trước được làm bằng chất liệu nhựa với cạnh trên được vát dạng hình tháp trông khỏe khoắn hơn. Logo MSI trên phiên bản Camo là phiên bản mới dạng 3D trông đẹp mắt hơn, tuy nhiên với chất liệu nhựa bóng thì sẽ rất dễ bị trầy xước cũng như logo không có đèn. Và điểm thay đổi ấn tượng nhất chính là họa tiết quân đội thuộc màu của lính đánh bộ dạng các ô vuông to nhỏ kĩ thuật số khác nhau thay vì một tông màu đen xám duy nhất. Ngoài ra, các họa tiết sẽ được làm mờ dần ở khu vực cạnh sau và bản lề của máy cùng với logo Camo. Thật sự mình cảm thấy thiết kế này rất đẹp mắt và trông cực kì hầm hố, tuy nhiên mình vẫn chưa biết được lí do tại sao MSI lại chỉ áp dụng phiên bản Camo cho dòng GE-series, còn về họa tiết thì MSI lấy cảm hứng từ tựa game Tom Clancy\'s Ghost Recon Wildlands.\r\n\r\n[​IMG]\r\nMặt trước trên phiên bản Camo Squad rất ngầu, nhưng tiếc không phải là chất liệu kim loại.\r\n\r\n[​IMG]\r\nPhiên bản GE-series thường.\r\n\r\n[​IMG]\r\nCạnh trái của máy với các cổng kết nối gồm: cổng khóa Kensington, cổng Ethernet LAN cùng công nghệ Killer LAN và Killer Shield, 2 cổng USB 3.0 được bố trí cách xa nhau, 1 cổng HDMI, 1 cổng mini-Display Port, 1 cổng USB 3.1 chuẩn kết nối Type-c giúp mang đến tốc độ sao chép dữ liệu tốc độ nhanh hơn. Ngoài ra, bạn có thể tân dụng cổng HDMI và mini-Display Port để xuất tín hiệu hình ảnh với chất lượng 4K lên hai màn hình khác nhau nhờ vào công nghệ Matrix Display.\r\n\r\n[​IMG]\r\nCạnh phải của máy bao gồm: cổng nguồn, khe cắm thẻ nhớ SD, 1 cổng USB 2.0, đầu đọc DVD. Máy có độ mỏng khoảng 27mm và có trong lượng khoảng 2,4kg, mức chấp nhận được với một chiếc laptop chơi game tầm trung hiện nay.\r\n', '2017-05-06 08:46:00'),
(3, 'Acer Switch 5: tablet Windows 2-in-1, 12\", làm mát bằng chất lỏng, không quạt, vân tay, Stylus', 'Hãng Acer hôm nay ra mắt hai chiếc tablet 2-trong-1 mang tên Switch 5 và Switch 3. Switch 5 thuộc hàng cao cấp, giá từ 799 USD, sử dụng thiết kế không cần quạt, làm mát bằng chất lỏng, màn hình 12\" độ phân giải cao còn Switch 3 thuộc hàng trung cấp với giá từ 399 Euro, dùng quạt tản nhiệt, cấu hình thấp hơn nhưng vẫn mang hình hài là một chiếc tablet lai laptop với chân chống dựng đứng máy và bàn phím rời gắn ngoài.\r\n\r\n​\r\n\r\nSwitch 5 có cảm biến vân tay tích hợp trong nút Home, có cả Windows Hello dùng để mở khóa và đăng nhập nhanh vào máy tính. Màn hình IPS cảm ứng có kích thước 12\", độ phân giải 2.160 x 1.440, được bán kèm với bút cảm ứng Acer Active Stylus có 1.024 cấp độ nhấn để tạo ra những nét vẽ có độ trung thực cao. Mặt sau của tablet có chân chống dùng để dựng đứng máy. Cho phép người dùng có thể thao tác điều chỉnh góc nghiêng chỉ bằng một tay. Acer chưa công bố bảng cấu hình đầy đủ nhưng cho biết máy dùng CPU Core i5 hoặc i7 thế hệ 7, card đồ họa tích hợp Intel HD Graphics 620 và thời lượng pin đạt 10,5 tiếng.\r\n\r\nacer-switch-5-2.jpg ​\r\nBên cạnh đó, bản Switch 3 có giá bán rẻ hơn phân nửa do cấu hình thấp hơn nhưng vẫn có chân chống, bàn phím rời (nhưng không có đèn nền như của Switch 5), bút cảm ứng. Switch 3 dùng quạt tản nhiệt chứ không có tản nhiệt bằng chất lỏng, màn hình IPS cảm ứng 12,2\" độ phân giải 1.920 x 1.200, pin 8 tiếng và dùng CPU Pentium hoặc Celeron.\r\n\r\nCả hai máy đều có camera trước 720p, một cổng USB-C và một cổng USB-A. Acer sẽ bắt đầu bán Switch 5 và Switch 3 tại Mỹ từ tháng 6 tới.', '2017-05-06 08:48:50'),
(4, 'Đánh giá ASUS K501 laptop màn FHD giá rẻ', 'Gần đây thấy các bạn có vẻ rất quan tâm đến một sản phẩm hoàn toàn mới của ASUS thuộc K series đó là K501L. Đây có thể được coi là sản phẩm cao cấp nhất trong K series với thiết kế nhôm nguyên khối, chip broadwell trang bị màn FHD (1920x1080), ram 4GB có thể nâng cấp lên 8GB hoặc 12GB, có khả năng nâng cấp thêm SSD.\r\nHiện bên mình chỉ về hàng K501LB model có giá rẻ nhất, dự kiến sẽ về K501LX với 2 cấu hình i5-5200U và i7-5500U, model i7U sẽ có kèm thêm ổ SSD sẵn. Đặc biệt K501LX trang bị card GTX950M. Có thể sẽ được trang bị thêm đèn bàn phím và 2 fan tản nhiệt. Cái này khi nào có hàng bên mình sẽ cập nhật sau :)\r\nQuay lại K501LB, model này có cấu hình i5-5200U ram 4GB, có thể update lên 8GB or 12GB, trang bị VGA NVIDIA GT940M 2GB, với thiết kế cực đẹp, mỏng nhẹ và rất sang trọng.\r\n\r\nSau đây mình sẽ đi cụ thể vào từng phần:\r\n\r\nThiết kế:\r\nVới vỏ nhôm nguyên khối khá đẹp, mặt lưng máy là một lớp vỏ nhôm đen phay xước nhìn khá sang trọng, tuy nhiên rất dễ bám vân tay.\r\n[​IMG] \r\n\r\nMặt dưới của máy là một lớp nhựa cứng, cầm khá là cứng cáp, việc nâng cấp và vệ sinh cũng khá dễ dàng, chỉ việc tháo nắp máy bên dưới là các bạn có thể làm được rồi. Tuy nhiên việc này mình ko khuyến khích tự làm ở nhà vì dễ dẫn đến mất bảo hành :)\r\n[​IMG] \r\n\r\nCổng kết nối: Cạnh phải của máy có 2 cổng USB 2.0, SD card, combo jack và ko có ổ DVD như chúng ta thường thấy ở các sản phẩm khác như K551, K555... Điều này sẽ làm cho máy trở nên mỏng nhẹ hơn.\r\n[​IMG] \r\nCạnh trái của máy có 2USB 3.0, cổng lan, HDMI. Ở đây chúng ta cũng không thấy cổng VGA, một thiết bị rất cần thiết trong việc trình chiếu.', '2017-05-06 08:49:27');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(9) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 NOT NULL,
  `price` int(9) NOT NULL DEFAULT '0',
  `category_id` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8,
  `rate` int(1) DEFAULT NULL,
  `views` int(9) NOT NULL DEFAULT '0',
  `buys` int(9) NOT NULL DEFAULT '0',
  `thumb` text CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `category_id`, `description`, `rate`, `views`, `buys`, `thumb`) VALUES
(1, 'LG 32 inch 32LF510D', 5490000, '1,7', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(2, 'Samsung 32 inch UA32J4003', 5590000, '1,5', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(3, 'iPhone 6s 16GB', 10000000, '2,11', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(4, 'Xiaomi Mi MIX (6GB/256GB)', 17000000, '2', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(5, 'HTC Desire 628', 4000000, '2,8', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(6, 'HTC U Ultra', 3000000, '2,8', 'Màn hình\r\nCông nghệ màn hình	Super LCD\r\nĐộ phân giải	2K (1440 x 2560 pixels)\r\nMàn hình rộng	Chính: 5.7\", phụ: 2.05\"\r\nMặt kính cảm ứng	Corning Gorilla Glass 5', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(7, 'GE72 7RE-073VN Apache Pro', 29900000, '3,16', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(8, '1 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(9, '2 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(10, '3 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(11, '4 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(12, '5 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg'),
(13, '6 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, 'http://cdn.fptshop.com.vn/Uploads/Originals/2016/12/9/636168892162994088_lenovo-IdeaPad-110-14IBR-1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
