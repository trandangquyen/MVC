-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2017 at 06:01 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(9) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8,
  `parent` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `parent`) VALUES
(1, 'Tivi', 'Các sản phẩm tivi', NULL),
(2, 'Điện thoại', 'Các sản phẩm điện thoại', NULL),
(3, 'Laptop', 'Máy tính xách tay', NULL),
(4, 'Toshiba', NULL, 1),
(5, 'Samsung', NULL, 1),
(6, 'Panasonic', NULL, 1),
(7, 'LG', NULL, 1),
(8, 'HTC', NULL, 2),
(9, 'BlackBerry', NULL, 2),
(10, 'Asus', NULL, 2),
(11, 'Apple', NULL, 2),
(12, 'HP', NULL, 3),
(13, 'Dell', NULL, 3),
(14, 'Asus', NULL, 3),
(15, 'Acer', NULL, 3),
(16, 'MSI', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(9) NOT NULL,
  `product_id` int(9) NOT NULL,
  `email` varchar(250) NOT NULL,
  `name` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `product_id`, `email`, `name`, `content`, `time`) VALUES
(1, 1, 'dsf@gmail.com', 'bao', 'Sản phẩm chất lượng cao', '2017-05-17 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(9) NOT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  `product_id` int(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `title`, `url`, `product_id`) VALUES
(1, 'anh 1', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-500x500.jpg', 7),
(2, 'anh 2', 'http://laptopnew.vn/image/cache/data/MSI/MSI%20GE/MSI%20GE72VR-3-500x500.jpg', 7);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(9) NOT NULL,
  `name` varchar(250) CHARACTER SET utf8 NOT NULL,
  `price` int(9) NOT NULL DEFAULT '0',
  `category_id` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `description` text CHARACTER SET utf8,
  `rate` int(1) DEFAULT NULL,
  `views` int(9) NOT NULL DEFAULT '0',
  `buys` int(9) NOT NULL DEFAULT '0',
  `thumb` text CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `category_id`, `description`, `rate`, `views`, `buys`, `thumb`) VALUES
(1, 'LG 32 inch 32LF510D', 5490000, '1,7', NULL, NULL, 0, 0, NULL),
(2, 'Samsung 32 inch UA32J4003', 5590000, '1,5', NULL, NULL, 0, 0, NULL),
(3, 'iPhone 6s 16GB', 10000000, '2,11', NULL, NULL, 0, 0, NULL),
(4, 'Xiaomi Mi MIX (6GB/256GB)', 17000000, '2', NULL, NULL, 0, 0, NULL),
(5, 'HTC Desire 628', 4000000, '2,8', NULL, NULL, 0, 0, NULL),
(6, 'HTC U Ultra', 3000000, '2,8', 'Màn hình\r\nCông nghệ màn hình	Super LCD\r\nĐộ phân giải	2K (1440 x 2560 pixels)\r\nMàn hình rộng	Chính: 5.7\", phụ: 2.05\"\r\nMặt kính cảm ứng	Corning Gorilla Glass 5', NULL, 0, 0, NULL),
(7, 'GE72 7RE-073VN Apache Pro', 29900000, '3,16', 'Model	MSI GE72 7RE-073VN\r\nCPU	Intel(R) core i7-7700HQ (2.8GHz upto 3.8GHz, 4Cores, 8Threads, 6M cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2400MHz (1x8GB) + 1 slot RAM. Max 32GB\r\nỔ cứng	1TB HDD 7200rpm Sata + 1 slot SSD M2 NMVe PCIe3x4\r\nCD/DVD	DVD±R/RW supperMulti DL', NULL, 0, 0, NULL),
(8, '1 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, NULL),
(9, '2 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, NULL),
(10, '3 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, NULL),
(11, '4 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, NULL),
(12, '5 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, NULL),
(13, '6 GS63VR 6RF-076VN', 39000000, '3,16', 'Model	MSI GS63VR 6RF-076VN Stealth Pro\r\nCPU	Intel(R) core i7-6700HQ (2.6GHz upto 3.5GHz, 4Cores, 8Threads, 6MB cache, FSB 8GT/s)\r\nRAM	8GB DDR4 2133MHz (1x8GB) + 1 slot RAM - Max 32GB', NULL, 0, 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
